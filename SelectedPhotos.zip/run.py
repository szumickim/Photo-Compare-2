import sys
sys.path.append("./data/")
sys.path.append("./data/userForm")

from data.userForm import userForm

if __name__ == "__main__":
    userForm.run()
