import json

# Otwieramy plik JSON w trybie odczytu (r)
with open(r'C:\Users\szumimic\Desktop\Python_scripts\Photo Compare 2\data\photo-compare-b4rJJn9k.json', 'r') as json_file:
    # Używamy funkcji json.load() do wczytania danych JSON z pliku
    my_dict = json.load(json_file)

# Teraz 'my_dict' zawiera zawartość pliku JSON jako słownik
print(my_dict)