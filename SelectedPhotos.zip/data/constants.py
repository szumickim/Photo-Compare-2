LAST_COLUMN_IN_EXPORT: int = 40
DIFFERENT: int = 2
SAME: int = 1

EXCEL_PATH = 'excel_path'
PHOTO_PATH = 'photo_path'

IS_DIFFERENT = "Different"
IS_SIMILAR = "Similar"
POSSIBLE: str = "Possible"
MANUAL: str = "Similar - manual"

ALL_IMAGES: str = "Show all images"
COMPARE: str = "Compare"

SIMILARITY_TYPE_COLUMN: str = "Similarity type"

PRODUCTS_ON_SCREEN: int = 3

SHOW_ALL_SUMMARY_FORMAT: int = 1
SUMMARY_FORMAT: int = 2

POPPLER_PATH = r"C:\poppler-23.05.0\Library\bin"
CREDENTIALS_PATH = 'data/userForm/login.txt'


TAG_TO_DELETE_KEY: str = 'To delete'
BME_CAT_DICT_KEY: str = 'BME_CAT'
EXCEL_DICT_KEY: str = 'Excel'
PROGRAM_DELETE_TAG: str = 'Delete'
PROGRAM_MFPNR: str = 'MFPNR'
PROGRAM_BME_TO_EXCEL: str = 'BME2EXCEL'

PDF: str = 'pdf'

SELECTED_PHOTOS: str = 'SelectedPhotos'
TEMP_ASSETS_FROM_STEP_FOLDER: str = 'AssetsFromStep'